class CustomerServiceRobot:
    def __init__(self):
        self.robot_available = True

    def handle_inquiry(self, inquiry):
        if self.robot_available:
            return self.robot_response(inquiry)
        else:
            return "没有空闲机器人，转接人工客服。"

    def handle_order_query(self, order_number):
        if self.robot_available:
            return self.robot_response(f"订单查询：{order_number}")
        else:
            return "没有空闲机器人，转接人工客服。"

    def handle_return_exchange(self, return_details):
        if self.robot_available:
            return self.robot_response(return_details)
        else:
            return "没有空闲机器人，转接人工客服。"

    def robot_response(self, message):
        # 模拟机器人回复用户消息
        if "办公时间" in message:
            return "智能客服机器人：我们的办公时间是工作日上午9点到下午5点。周末和节假日休息。"
        elif "投诉" in message:
            return "智能客服机器人：非常抱歉听到您的投诉，请您填写我们的投诉表格，并详细描述您的问题。我们将尽快安排工作人员处理。"
        elif "办理户口业务的时间" in message:
            return "智能客服机器人：办理户口业务的时间是每周一、三、五的上午10点到12点。请您提前准备好相关材料前来办理。"
        else:
            return f"智能客服机器人：{message}"


class CustomerServiceAgent:
    def __init__(self):
        self.robot = CustomerServiceRobot()

    def handle_customer_inquiry(self, inquiry):
        if self.robot.robot_available:
            response = self.robot.handle_inquiry(inquiry)
            if "转接" in response:
                return self.redirect_to_human(response)
            else:
                return response
        else:
            return self.redirect_to_human("没有空闲机器人，转接人工客服。")

    def handle_order_query(self, order_number):
        if self.robot.robot_available:
            response = self.robot.handle_order_query(order_number)
            if "转接" in response:
                return self.redirect_to_human(response)
            else:
                return response
        else:
            return self.redirect_to_human("没有空闲机器人，转接人工客服。")

    def handle_return_exchange(self, return_details):
        if self.robot.robot_available:
            response = self.robot.handle_return_exchange(return_details)
            if "转接" in response:
                return self.redirect_to_human(response)
            else:
                return response
        else:
            return self.redirect_to_human("没有空闲机器人，转接人工客服。")
        
    def redirect_to_human(self, message):
        # 模拟转接到人工客服
        return f"正在为您转接至人工客服：{message}"

# 实现输入对话并机器人自动回答
if __name__ == "__main__":
    agent = CustomerServiceAgent()
    while True:
        user_input = input("请输入您的问题：")
        if user_input.lower() == "退出":
            print("智能客服机器人：感谢您的咨询，再见！")
            break
        response = agent.handle_customer_inquiry(user_input)
        print(response)
