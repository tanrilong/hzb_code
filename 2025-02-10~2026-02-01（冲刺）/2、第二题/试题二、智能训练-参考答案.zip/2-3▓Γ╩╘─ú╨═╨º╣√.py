import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator

# 加载模型
model = tf.keras.models.load_model('D:/Desktop/卷一/提交资料/题目2/2-2model_test.h5')

test_dir = 'D:/Desktop/卷一提/交资料/题目2/测试集'

# 超参数
img_height = 224
img_width = 224
batch_size = 32
learning_rate = 0.001
epochs = 10

datagen = ImageDataGenerator(rescale=1./255)

test_generator = datagen.flow_from_directory(
    test_dir,
    target_size=(img_height, img_width),
    batch_size=batch_size,
    class_mode='categorical',  # 返回独热编码的标签
    shuffle=False
)

# 评估模型
loss, accuracy = model.evaluate(test_generator)
print(f"Test Accuracy: {accuracy * 100:.2f}%")
