from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.models import Model
from tensorflow.keras.layers import GlobalAveragePooling2D, Dense
from tensorflow.keras.optimizers import Adam

# 数据路径和超参数
train_dir = 'D:/Desktop/卷一/提交资料/题目2/训练集'
img_height, img_width = 224, 224
batch_size, epochs, learning_rate = 32, 10, 0.001

# 数据增强和预处理
datagen = ImageDataGenerator(rescale=1. / 255)
train_generator = datagen.flow_from_directory(
    train_dir, target_size=(img_height, img_width), batch_size=batch_size, class_mode='categorical', shuffle=False)

# 构建模型
base_model = ResNet50(weights='imagenet', include_top=False, input_shape=(img_height, img_width, 3))
x = GlobalAveragePooling2D()(base_model.output)
output = Dense(train_generator.num_classes, activation='softmax')(x)
model = Model(inputs=base_model.input, outputs=output)

# 冻结预训练模型的权重并编译模型
base_model.trainable = False
model.compile(optimizer=Adam(learning_rate=learning_rate), loss='binary_crossentropy', metrics=['accuracy'])

# 训练并保存模型
model.fit(train_generator, epochs=epochs)
model.save('D:/Desktop/卷一/提交资料/题目2/2-2model_test.h5')

print("训练完成！")
