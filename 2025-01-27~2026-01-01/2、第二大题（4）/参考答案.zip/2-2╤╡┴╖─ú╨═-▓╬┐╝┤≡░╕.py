from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications import VGG16
from tensorflow.keras.models import Model
from tensorflow.keras.layers import GlobalAveragePooling2D, Dense
from tensorflow.keras.optimizers import Adam

# 数据路径
train_dir = 'D:/Desktop/卷一/提交资料/题目2/训练集'

# 超参数
img_height = 224
img_width = 224
batch_size = 32
learning_rate = 0.001
epochs = 10

# 数据增强和预处理
datagen = ImageDataGenerator(rescale=1./255)

train_generator = datagen.flow_from_directory(
    train_dir,
    target_size=(img_height, img_width),
    batch_size=batch_size,
    class_mode='categorical',  # 返回独热编码的标签
    shuffle=False  # 不打乱顺序
)

# 构建模型
base_model = VGG16(weights='imagenet', include_top=False, input_shape=(img_height, img_width, 3))
x = GlobalAveragePooling2D()(base_model.output)
output = Dense(1, activation='sigmoid')(x)

model = Model(inputs=base_model.input, outputs=output)

# 冻结预训练模型的权重
base_model.trainable = False

model.compile(optimizer=Adam(learning_rate=learning_rate),
              loss='binary_crossentropy',  # 使用 categorical_crossentropy 损失函数
              metrics=['accuracy'])

# 训练模型
model.fit(
    train_generator,
    epochs=epochs
)

# 保存模型
model.save('D:/Desktop/卷一/提交资料/题目2/2-2model_test.h5')

print("训练完成！")
