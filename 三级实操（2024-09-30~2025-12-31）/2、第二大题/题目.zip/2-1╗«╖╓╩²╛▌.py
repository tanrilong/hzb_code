import os
import random
import shutil

# 定义数据集文件夹路径
data_folder = "D:/Desktop/06.素材文件（终版）/卷三/资源包/题2/人脸识别"
# 定义训练集和测试集比例
train_ratio = 
test_ratio = 

# 获取数据集文件列表
data_files = os.listdir(data_folder)
# 打乱文件列表顺序
random.shuffle(data_files)

# 划分训练集和测试集的索引
train_split = int(len(data_files) * train_ratio)
train_files = data_files[:train_split]
test_files = data_files[train_split:]

# 创建训练集和测试集文件夹
train_folder = ""
test_folder = ""
os.makedirs(train_folder, exist_ok=True)
os.makedirs(test_folder, exist_ok=True)

# 将文件复制到相应的文件夹
for file in train_files:
    shutil.copy(os.path.join(data_folder, file), os.path.join(train_folder, file))
for file in test_files:
    shutil.copy(os.path.join(data_folder, file), os.path.join(test_folder, file))
