import os
from PIL import Image
import numpy as np
from imgaug import augmenters as iaa

# 读取图片路径
input_folder = "D:/Desktop/06.素材文件（终版）/卷三/资源包/题1/data_force"
output_folder = "D:/Desktop/06.素材文件（终版）/卷三/提交资料/题目1/1-2数据增强"

# 创建输出文件夹
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# 数据增强的参数设置
augmenter = iaa.Sequential([
    iaa.Affine(),  # 旋转45度
])

def pil_to_np(image):
    """Convert PIL image to numpy array."""
    return np.array(image)

def np_to_pil(image):
    """Convert numpy array to PIL image."""
    return Image.fromarray(image)

# 读取并处理图片
for filename in os.listdir(input_folder):
    if filename.endswith(".jpg") or filename.endswith(".png"):
        # 读取图片
        image_path = os.path.join(input_folder, filename)
        image = Image.open(image_path)
        image_np = pil_to_np(image)
        
        # 数据增强
        images_aug = augmenter()  # 生成3倍的数据
        
        # 保存增强后的图片
        for i, img_aug in enumerate(images_aug):
            img_aug_pil = np_to_pil(img_aug)
            output_path = os.path.join(output_folder, f"{os.path.splitext(filename)[0]}_aug_{i}.png")
            img_aug_pil.save(output_path)

print("数据增强完成，增强后的图片已保存至D:/Desktop/06.素材文件（终版）/卷三/提交资料/题目1/1-2数据增强。")
