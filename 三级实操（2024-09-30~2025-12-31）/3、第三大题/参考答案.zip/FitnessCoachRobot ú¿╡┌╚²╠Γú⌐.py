class FitnessCoachRobot:
    def __init__(self):
        self.exercise_log = []

    def recommend_plan(self, fitness_goal):
        # 根据常见的健身目标推荐健身计划
        plans = {
            "减肥": "每周进行5次有氧运动和3次力量训练。",
            "增肌": "每周进行4次力量训练和2次有氧运动。",
            "保持": "每周进行3次适度有氧运动和2次力量训练。"
        }
        return plans.get(fitness_goal, "请提供有效的健身目标。")

    def suggest_diet(self, diet_preference):
        # 根据饮食偏好建议相应的饮食
        diets = {
            "素食": "专注于高蛋白素食选项，如豆腐、扁豆和鹰嘴豆。",
            "低碳水化合物": "强调瘦肉、鱼类和绿色蔬菜，减少碳水化合物。",
            "均衡": "确保蛋白质、碳水化合物和脂肪的均衡摄入。"
        }
        return diets.get(diet_preference, "请提供有效的饮食偏好。")
    
    def record_exercise(self, exercise_type, duration):
        # 记录运动类型和持续时间
        self.exercise_log.append({"类型": exercise_type, "时长": duration})
        return f"已记录运动：{exercise_type}，持续时间为{duration}分钟。"


# 创建 FitnessCoachRobot 的实例
robot = FitnessCoachRobot()

# 展示 recommend_plan 方法
fitness_plan = robot.recommend_plan("增肌")

# 展示 suggest_diet 方法
diet_suggestion = robot.suggest_diet("素食")

# 展示 record_exercise 方法
exercise_confirmation = robot.record_exercise("跑步", 30)

# 输出完整效果
fitness_plan, diet_suggestion, exercise_confirmation, robot.exercise_log
